SELECT version();

drop DATABASE if EXISTS servicMoto;

CREATE DATABASE servicMoto;

use servicMoto;
-- tabla de clientes
CREATE Table Clientes(
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100)NOT NULL,
    telefono VARCHAR(20),
    email VARCHAR(100),
    direccion TEXT);

--tabla de moto 
CREATE TABLE Motos(
    id_moto INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT,
    marca VARCHAR(50),
    modelo VARCHAR(50),
    año INT,
    patente VARCHAR(20) UNIQUE,
    FOREIGN KEY(id_cliente) REFERENCES Clientes (id_cliente));

--Tabla de empleados 
CREATE Table Empleados(
    id_empleado INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) not NULL,
    apellido VARCHAR(100)not NULL,
    especialidad VARCHAR(100),
    telefono VARCHAR(20));

--tabla de servicios disponibles
CREATE Table Servicios(
    id_servicio INT PRIMARY KEY AUTO_INCREMENT,
    nombre_servicio VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2)NOT NULL);

--Tabla de ordenes de servicio
CREATE Table OrdenesServicio(
    id_orden INT PRIMARY KEY AUTO_INCREMENT,
    id_moto INT,
    id_empleado INT,
    fecha_ingreso DATE,
    fecha_entrega DATE,
    estado VARCHAR(50),
    observaciones TEXT,
    FOREIGN key (id_moto) REFERENCES Motos(id_moto),
    FOREIGN KEY (id_empleado) REFERENCES Empleados(id_empleado));

--Tabla de detalles de servicio realizados en cada orden
CREATE Table DetalleOrdenServicio(
    id_detalle INT PRIMARY KEY AUTO_INCREMENT,
    id_orden INT,
    id_servicio INT,
    cantidad INT DEFAULT 1,
    subtotal DECIMAL(10,2),
    FOREIGN KEY(id_orden) REFERENCES OrdenesServicio(id_orden),
    FOREIGN key (id_servicio) REFERENCES Servicios(id_servicio));

show tables;




