-- Active: 1761764610587@@127.0.0.1@3306@mysql
use servicMoto;
INSERT INTO Clientes (nombre, apellido, telefono, email, direccion) VALUES
('Juan', 'Pérez', '1122334455', 'juan.perez@email.com', 'Av. Siempre Viva 123'),
('María', 'Gómez', '1133445566', 'maria.gomez@email.com', 'Calle Falsa 456'),
('Carlos', 'López', '1144556677', 'carlos.lopez@email.com', 'Ruta 9 Km 25');

INSERT INTO Motos (id_cliente, marca, modelo, año, patente) VALUES
(1, 'Honda', 'CBR600RR', 2020, 'ABC123'),
(2, 'Yamaha', 'MT-03', 2022, 'XYZ789'),
(3, 'Suzuki', 'GSX-R750', 2019, 'LMN456');

INSERT INTO Empleados (nombre, apellido, especialidad, telefono) VALUES
('Luis', 'Martínez', 'Mecánica general', '1155667788'),
('Ana', 'Fernández', 'Electricidad', '1166778899'),
('Pedro', 'Ramírez', 'Diagnóstico electrónico', '1177889900');

INSERT INTO Servicios (nombre_servicio, descripcion, precio) VALUES
('Cambio de aceite', 'Reemplazo de aceite de motor y filtro', 3500.00),
('Alineación', 'Ajuste de la dirección y suspensión', 2500.00),
('Diagnóstico electrónico', 'Chequeo completo del sistema eléctrico', 4000.00);

INSERT INTO OrdenesServicio (id_moto, id_empleado, fecha_ingreso, fecha_entrega, estado, observaciones) VALUES
(1, 1, '2025-11-01', '2025-11-03', 'Finalizado', 'Cliente solicitó revisión completa'),
(2, 2, '2025-11-02', NULL, 'En proceso', 'Problemas con el encendido'),
(3, 3, '2025-11-03', NULL, 'Pendiente', 'Aún no se ha revisado');

INSERT INTO DetalleOrdenServicio (id_orden, id_servicio, cantidad, subtotal) VALUES
(1, 1, 1, 3500.00),
(1, 2, 1, 2500.00),
(2, 3, 1, 4000.00);








