package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.DetalleOrdenServicio;

public class TestDetalleOrdenServicio {
    public static void main(String[] args) {
        System.out.println("--detalleOrdenServicio01--");
        DetalleOrdenServicio detalleOrdenServicio01 = new
         DetalleOrdenServicio(1, 2, 1, 3, 20000.0);
        System.out.println(detalleOrdenServicio01);
    }
}
