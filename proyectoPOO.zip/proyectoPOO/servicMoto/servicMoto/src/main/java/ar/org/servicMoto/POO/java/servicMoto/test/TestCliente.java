package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Cliente;

public class TestCliente {
    public static void main(String[] args) {
        System.out.println("--cliente01--");
        Cliente cliente1 = new Cliente(1, "leandro", "saavedra", "12345678", "saaa@lean123", "siemprevivo123");
        System.out.println(cliente1);

    }

}
