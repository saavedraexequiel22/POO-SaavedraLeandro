package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Servicio;

public class TestServicio {
    public static void main(String[] args) {
        System.out.println("--servicio01--");
        Servicio servicio01 = new Servicio(1, "servic completo", "revision general", 20000.0);
        System.out.println(servicio01);
    }

}
