package ar.org.servicMoto.POO.java.servicMoto.Entities;

public class Servicio {
    private int idServicio;
    private String nombreServicio;
    private String descripcion;
    private Double precio;
    
}
