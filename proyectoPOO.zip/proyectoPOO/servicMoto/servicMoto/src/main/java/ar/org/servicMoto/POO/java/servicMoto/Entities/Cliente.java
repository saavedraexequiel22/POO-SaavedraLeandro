package ar.org.servicMoto.POO.java.servicMoto.Entities;

public class Cliente {
    private int idCliente;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private String direccion;
    
}
