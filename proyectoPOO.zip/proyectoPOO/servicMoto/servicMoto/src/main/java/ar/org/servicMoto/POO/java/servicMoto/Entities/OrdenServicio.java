package ar.org.servicMoto.POO.java.servicMoto.Entities;

import java.time.LocalDate;

public class OrdenServicio {
    private int idOrden;
    private int idMoto;
    private int idEmpleado;
    private LocalDate fechaDeIngreso;
    private LocalDate FechaDeEntrega;
    private String estado;
    private String observaciones;
    






    
}
