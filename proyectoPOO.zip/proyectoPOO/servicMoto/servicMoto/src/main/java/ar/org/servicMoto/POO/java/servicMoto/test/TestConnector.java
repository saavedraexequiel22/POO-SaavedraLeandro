package ar.org.servicMoto.POO.java.servicMoto.test;

import java.sql.Connection;
import java.sql.ResultSet;

import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;


public class TestConnector {
    
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select 'Conectado'");
            if(rs.next())       System.out.println(rs.getString(1));
            else                System.out.println("No Conectado");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No Conectado");
        }
    }
    
}
