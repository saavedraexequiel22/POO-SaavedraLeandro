package ar.org.servicMoto.POO.java.servicMoto.Entities;

public class DetalleOrdenServicio {
    private int idDetalle;
    private int idOrden;
    private int idServicio;
    private int cantidad;
    private double subTotal;
    
}
