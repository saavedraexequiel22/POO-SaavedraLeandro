package ar.org.servicMoto.POO.java.servicMoto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicMotoApplicationTests {

	@Test
	void contextLoads() {
	}

}
