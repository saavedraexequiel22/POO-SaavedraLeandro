-- Active: 1758919629365@@127.0.0.1@3306@colegio
use servicMoto;

-- obtener varias tablas para mostrar que servicios se hicieron, a que moto, de que cliente y cuanto costaron:
SELECT 
    Clientes.nombre AS nombre_cliente,
    Clientes.apellido AS apellido_cliente,
    Motos.marca,
    Motos.modelo,
    Servicios.nombre_servicio,
    DetalleOrdenServicio.cantidad,
    DetalleOrdenServicio.subtotal
FROM DetalleOrdenServicio
JOIN OrdenesServicio ON DetalleOrdenServicio.id_orden = OrdenesServicio.id_orden
JOIN Motos ON OrdenesServicio.id_moto = Motos.id_moto
JOIN Clientes ON Motos.id_cliente = Clientes.id_cliente
JOIN Servicios ON DetalleOrdenServicio.id_servicio = Servicios.id_servicio;

-- Consulta las ordenes con la informacion de la moto y el empleado que la realizo:
SELECT 
    OrdenesServicio.id_orden,
    Motos.patente,
    Empleados.nombre AS nombre_empleado,
    Empleados.apellido AS apellido_empleado,
    OrdenesServicio.fecha_ingreso,
    OrdenesServicio.estado
FROM OrdenesServicio
JOIN Motos ON OrdenesServicio.id_moto = Motos.id_moto
JOIN Empleados ON OrdenesServicio.id_empleado = Empleados.id_empleado;

-- El total acumulado de todos los servicios realizados en esa orden especifica(Orden ID=1):
SELECT 
    OrdenesServicio.id_orden,
    SUM(DetalleOrdenServicio.subtotal) AS total_orden
FROM OrdenesServicio
JOIN DetalleOrdenServicio ON OrdenesServicio.id_orden = DetalleOrdenServicio.id_orden
WHERE OrdenesServicio.id_orden = 1
GROUP BY OrdenesServicio.id_orden;

-- Datos del cliente y su moto, cada orden de servicio con sus fechas y estado, Los servicios realizados, cantidad y costo.
SELECT 
    Clientes.nombre AS nombre_cliente,
    Clientes.apellido AS apellido_cliente,
    Motos.marca,
    Motos.modelo,
    Motos.patente,
    OrdenesServicio.id_orden,
    OrdenesServicio.fecha_ingreso,
    OrdenesServicio.fecha_entrega,
    OrdenesServicio.estado,
    Servicios.nombre_servicio,
    DetalleOrdenServicio.cantidad,
    DetalleOrdenServicio.subtotal
FROM Clientes
JOIN Motos ON Clientes.id_cliente = Motos.id_cliente
JOIN OrdenesServicio ON Motos.id_moto = OrdenesServicio.id_moto
JOIN DetalleOrdenServicio ON OrdenesServicio.id_orden = DetalleOrdenServicio.id_orden
JOIN Servicios ON DetalleOrdenServicio.id_servicio = Servicios.id_servicio
WHERE Clientes.id_cliente = 1;

-- Todos los clientes
SELECT * FROM Clientes;

-- todas las motos
SELECT * from Motos;

--todas las ordenServicio
SELECT * FROM OrdenesServicio;

--todos los servicios
SELECT * FROM Servicios;

SELECT * FROM DetalleOrdenServicio;



