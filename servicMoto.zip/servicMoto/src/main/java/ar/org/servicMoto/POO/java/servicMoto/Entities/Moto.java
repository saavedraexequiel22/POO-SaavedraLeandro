package ar.org.servicMoto.POO.java.servicMoto.Entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor

public class Moto {
    private int id;
    private int idCliente;
    private String marca;
    private String modelo;
    private int año;
    private String patente;
}
