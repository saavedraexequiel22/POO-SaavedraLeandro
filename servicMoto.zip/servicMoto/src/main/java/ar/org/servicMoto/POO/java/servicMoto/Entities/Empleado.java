package ar.org.servicMoto.POO.java.servicMoto.Entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor

public class Empleado {
    private int idEmpleado;
    private String nombre;
    private String apellido;
    private String especialidad;
    private String telefono;
   
}
