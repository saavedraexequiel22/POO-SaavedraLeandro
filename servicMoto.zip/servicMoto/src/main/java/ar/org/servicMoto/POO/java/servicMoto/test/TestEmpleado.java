package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Empleado;

public class TestEmpleado {
    public static void main(String[] args) {
        System.out.println("--empleado01--");
        Empleado empleado01 = new Empleado(1, "franco", "diaz", "mecanica general", "123456");
        System.out.println(empleado01);

    }
}