package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.DetalleOrdenServicio;
import ar.org.servicMoto.POO.java.servicMoto.repositories.DetalleOrdenServicioRepository;

public class TestDetalleOrdenServicioRepository {
    public static void main(String[] args) {
        DetalleOrdenServicioRepository de = new DetalleOrdenServicioRepository();

        DetalleOrdenServicio detalleOrdenServicio = new DetalleOrdenServicio(1, 3, 3, 1, 222220);
        de.save(detalleOrdenServicio);
        System.out.println(detalleOrdenServicio);

        de.remove(de.getById(11));
        System.out.println("---------------------------");
        de.getAll().forEach(System.out::println);

        System.out.println("---------------------------");
        de.getAll().forEach(System.out::println);

    }

}
