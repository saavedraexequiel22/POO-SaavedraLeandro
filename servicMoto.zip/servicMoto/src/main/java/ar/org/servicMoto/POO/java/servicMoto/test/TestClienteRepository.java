package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Cliente;
import ar.org.servicMoto.POO.java.servicMoto.repositories.ClienteRepository;

public class TestClienteRepository {
    public static void main(String[] args) {
        ClienteRepository ar = new ClienteRepository();

        Cliente cliente = new Cliente(6, "Laura", "Saavedra", "12334456", "leand@gmail", "salcedo 3333");
        ar.save(cliente);
        System.out.println(cliente);

        ar.remove(ar.getById(1));
        System.out.println("--------------------");
        ar.getAll().forEach(System.out::println);

        System.out.println("----------------------------");
        ar.getLikeApellido("ez").forEach(System.out::println);

    }

}
