package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Servicio;
import ar.org.servicMoto.POO.java.servicMoto.repositories.ServicioRepository;

public class TestServicioRepository {
    public static void main(String[] args) {
        ServicioRepository ser = new ServicioRepository();

        Servicio servicio = new Servicio(4, "cambio de aceite", "cambio de aceite", 2000.0);
        ser.save(servicio);
        System.out.println(servicio);

        System.out.println("-----------------------------");
        ser.getAll().forEach(System.out::println);
    }

}
