package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Moto;
import ar.org.servicMoto.POO.java.servicMoto.repositories.ClienteRepository;
import ar.org.servicMoto.POO.java.servicMoto.repositories.MotoRepository;

@Controller

public class MotoControlers {
    private MotoRepository mr=new MotoRepository();
    private ClienteRepository cr=new ClienteRepository();
    private String mensaje= "Ingrese una nueva Moto";

    @GetMapping("Motos")
    public String getMotos(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        Moto moto=new Moto();
        model.addAllAttributes("Clientes", cr.getAll());
        model.addAllAttributes("mensaje", mensaje);
        
    }
    
}
