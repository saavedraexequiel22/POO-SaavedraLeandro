package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Moto;
import ar.org.servicMoto.POO.java.servicMoto.repositories.MotoRepository;

public class TestMotoRepository {

    public static void main(String[] args) {
        MotoRepository mo = new MotoRepository();

        Moto moto = new Moto(6, 1, "Honda", "CBR600RR", 2020, "ABC119");
        mo.save(moto);
        System.out.println(moto);

        mo.remove(mo.getById(1));

        System.out.println("-----------------------------");
        mo.getAll().forEach(System.out::println);

        System.out.println("**************************");
        mo.getLikeMarca("Ho").forEach(System.out::println);
    }
}
