package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Moto;
import ar.org.servicMoto.POO.java.servicMoto.repositories.ClienteRepository;
import ar.org.servicMoto.POO.java.servicMoto.repositories.MotoRepository;

@Controller

public class MotoController {
    private MotoRepository mr=new MotoRepository();
    private ClienteRepository cr=new ClienteRepository();
    private String mensaje= "Ingrese una nueva Moto";

    @GetMapping("/Motos")
    public String getMotos(Model model, @RequestParam(name = "Moto", defaultValue = "")String buscar){
        Moto moto=new Moto();
        model.addAttribute("Clientes", cr.getAll());
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("MotoForm", moto);
        model.addAttribute("ListaMotos", mr.getLikeMarca(buscar));
        return "moto";
    }

    @PostMapping("/guardarMotos")
    public String guardarMoto(@ModelAttribute Moto moto){
        mr.save(moto);
        if(moto.getId()>0) mensaje= "Se guardo  la moto " + moto.getId();
        else mensaje="no se guardo la moto";
        return "redirect:/moto";

    }
    
}
