package ar.org.servicMoto.POO.java.servicMoto.test;

import java.time.LocalDate;

import ar.org.servicMoto.POO.java.servicMoto.Entities.OrdenServicio;
import ar.org.servicMoto.POO.java.servicMoto.repositories.OrdenServicioRepository;

public class TestOrdenServicioRepository {
    public static void main(String[] args) {
        OrdenServicioRepository ord = new OrdenServicioRepository();

        // crear nuevas ordenes
        OrdenServicio orden1 = new OrdenServicio(5, 2, 2, LocalDate.now(), LocalDate.now().plusDays(5), "pendiente",
                "cambio de aceite");
        System.out.println(orden1);

        OrdenServicio orden2 = new OrdenServicio(
                0,
                1,
                3,
                LocalDate.now(),
                LocalDate.now().plusDays(3),
                "finalizado",
                "Revisión general");
        System.out.println(orden2);

        // Guardar en la base de datos
        ord.save(orden1);
        ord.save(orden2);

        System.out.println("Órdenes guardadas con ID:");
        System.out.println("Orden1 -> " + orden1.getIdOrden());
        System.out.println("Orden2 -> " + orden2.getIdOrden());
    }

}
