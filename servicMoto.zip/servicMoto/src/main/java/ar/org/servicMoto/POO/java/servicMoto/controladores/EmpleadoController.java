package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Empleado;
import ar.org.servicMoto.POO.java.servicMoto.repositories.EmpleadoRepository;

@Controller
public class EmpleadoController {
    private EmpleadoRepository emp = new EmpleadoRepository();
    private String mensaje = "Ingrese el empleado";

    @GetMapping("/Empleados")
    public String getEmpleados(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        Empleado empleado = new Empleado();
        empleado.setApellido(" ");
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("empleado", empleado);
        model.addAttribute("listaEmpleado", emp.getLikeApellido(buscar));
        return "empleado";
    }
    @PostMapping("/guardarEmpleado")
    public String guardarEmpleados(@ModelAttribute Empleado empleado) {
        emp.save(empleado);
        if (empleado.getIdEmpleado() > 0)
            mensaje = "se guardo empleado" + empleado.getIdEmpleado();
        else
            mensaje = "No se guardo empleado";
    
        return "redirect:/empleados";

    }   
}
