package ar.org.servicMoto.POO.java.servicMoto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicMotoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicMotoApplication.class, args);
	}

}
