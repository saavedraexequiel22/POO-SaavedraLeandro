package ar.org.servicMoto.POO.java.servicMoto.test;

import java.time.LocalDate;

import ar.org.servicMoto.POO.java.servicMoto.Entities.OrdenServicio;

public class TestOrdenServicio {
    public static void main(String[] args) {
        System.out.println("--ordenServicio01--");
        OrdenServicio ordenServicio01 = new OrdenServicio(1, 2, 1,
                LocalDate.of(2025, 8, 16), LocalDate.of(2025, 9, 17),
                "finalizado", "El cliente solicito servic completo");
        System.out.println(ordenServicio01);
    }

}
