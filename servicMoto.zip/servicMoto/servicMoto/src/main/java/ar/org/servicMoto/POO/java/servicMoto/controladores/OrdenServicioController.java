package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.servicMoto.POO.java.servicMoto.Entities.OrdenServicio;
import ar.org.servicMoto.POO.java.servicMoto.repositories.OrdenServicioRepository;

@Controller
public class OrdenServicioController {
    private OrdenServicioRepository orden = new OrdenServicioRepository();
    private String mensaje = "Ingrese una nueva Orden de Servicio";

    @GetMapping("/ordenServicio")
    public String getordenServicio(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        OrdenServicio ordenServicio = new OrdenServicio();
        model.addAttribute("estado", orden.getAll());
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("ordenServicio", ordenServicio);
        model.addAttribute("listaOrdenServicio", orden.getLikeEstado(buscar));
        return "ordenServicio";

    }

    @PostMapping("/guardarOrdenServicio")
    public String guardarOrdenServicio(@ModelAttribute OrdenServicio ordenServicio) {
        orden.save(ordenServicio);
        if (ordenServicio.getIdOrden() > 0)
            mensaje = "Se guardo Orden Servicio" + ordenServicio.getIdOrden();
        else
            mensaje = "No se guardo orden del servicio";
        return "redirect:/ordenServicio";
    }

}
