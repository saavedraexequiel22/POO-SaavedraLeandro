package ar.org.servicMoto.POO.java.servicMoto.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Empleado;
import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;

public class EmpleadoRepository {

    private Connection conn = Connector.getConnection();

    public void save(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into Empleados (nombre,apellido,especialidad,telefono) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setString(3, empleado.getEspecialidad());
            ps.setString(4, empleado.getTelefono());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                empleado.setIdEmpleado(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from Empleados where id_empleado=?")) {
            ps.setInt(1, empleado.getIdEmpleado());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Empleado getById(int id) {
        return getAll()
                .stream()
                .filter(e -> e.getIdEmpleado() == id)
                .findAny()
                .orElse(new Empleado());

    }

    public List<Empleado> getAll() {
        List<Empleado> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from Empleados")) {
            while (rs.next()) {
                list.add(
                        new Empleado(
                                rs.getInt("id_empleado"),
                                rs.getString("nombre"),
                                rs.getString("apellido"),
                                rs.getString("especialidad"),
                                rs.getString("telefono")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Empleado> getLikeApellido(String apellido) {
        return getAll()
                .stream()
                .filter(e -> e.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .toList();
    }

}
