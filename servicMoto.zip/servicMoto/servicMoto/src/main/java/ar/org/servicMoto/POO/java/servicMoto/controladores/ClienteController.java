package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Cliente;
import ar.org.servicMoto.POO.java.servicMoto.repositories.ClienteRepository;

@Controller
public class ClienteController {
    private ClienteRepository cr = new ClienteRepository();
    private String mensaje = "Ingrese el cliente";

    @GetMapping("/cliente")
    public String getClientes(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        Cliente cliente = new Cliente();
        cliente.setApellido(" ");
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cliente", cliente);
        model.addAttribute("listaCliente", cr.getLikeApellido(buscar));
        return "cliente";
    }

    @PostMapping("/guardarCliente")
    public String guardarClientes(@ModelAttribute Cliente cliente) {
        cr.save(cliente);
        if (cliente.getIdCliente() > 0)
            mensaje = "se guardo cliente" + cliente.getIdCliente();
        else
            mensaje = "No se guardo cliente";
    
        return "redirect:/cliente";

    }

}
