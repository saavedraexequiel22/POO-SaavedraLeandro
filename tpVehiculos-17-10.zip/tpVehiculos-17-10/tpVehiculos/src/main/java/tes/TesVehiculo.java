package tes;

import ar.or.centro08.curso.java.tpVehiculos.entities.AutoClasico;
import ar.or.centro08.curso.java.tpVehiculos.entities.AutoNuevo;
import ar.or.centro08.curso.java.tpVehiculos.entities.Bondi;
import ar.or.centro08.curso.java.tpVehiculos.entities.Radio;

public class TesVehiculo {
    public static void main(String[] args) {
        System.out.println("**Radio**");
        Radio r01 = new Radio("sony", 50);
        Radio r02 = new Radio("Pioner", 60);
        System.out.println(r01);
        System.out.println(r02);

        System.out.println("***AutoClasico***");
        AutoClasico clasico = new AutoClasico("rojo", "Toyota", 1978, 2200000.0);
        clasico.cambiarRadio("philips", 300);
        System.out.println(clasico);
   

        System.out.println("***AutoNuevo**");
        AutoNuevo nuevo = new AutoNuevo("rojo", "Toyota", 1970, 200000.0, "sony", 200);
        nuevo.cambiarRadio("B52", 200);
        System.out.println(nuevo);
      

        System.out.println("**Bondi**");
        Bondi bondi1 = new Bondi("verde", "VMW", 1970, 2244.0);
        bondi1.cambiarRadio("Philco", 50);
        System.out.println(bondi1);
      
    }

}
