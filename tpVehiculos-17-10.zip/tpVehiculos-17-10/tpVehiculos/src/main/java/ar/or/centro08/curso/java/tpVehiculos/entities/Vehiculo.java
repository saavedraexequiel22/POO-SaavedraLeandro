
/*
 *contiene atributos y metodos comunes a todo los tipos de vehiculos. 
 * 
 */
package ar.or.centro08.curso.java.tpVehiculos.entities;

public abstract class Vehiculo {
    protected String color;
    protected String marca;
    protected int modelo;
    protected double precio;
    protected Radio radio;

    public Vehiculo(String color, String marca, int modelo, double precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
    public void cambiarRadio(String marca, int potencia) {
        this.radio=new Radio(marca, potencia);
        
    }

    public Radio getRadio() {
        return radio;
    }

    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio
                + ", radio=" + radio + "]";
    }

}
