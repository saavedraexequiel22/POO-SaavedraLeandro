package ar.or.centro08.curso.java.tpVehiculos.entities;

public class AutoClasico extends Vehiculo {
    public AutoClasico(String color, String marca, int modelo, double precio) {
        super(color, marca, modelo, precio);// usa el contructor sin radio
    }

}
