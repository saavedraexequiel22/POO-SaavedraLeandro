package ar.or.centro08.curso.java.tpVehiculos.entities;

public class AutoNuevo extends Vehiculo {
    public AutoNuevo(String color, String marca, int modelo, double precio, String marcaRadio, int potencia) {
        super(color, marca, modelo, precio);
       super.cambiarRadio(marcaRadio, potencia);
    }

}
