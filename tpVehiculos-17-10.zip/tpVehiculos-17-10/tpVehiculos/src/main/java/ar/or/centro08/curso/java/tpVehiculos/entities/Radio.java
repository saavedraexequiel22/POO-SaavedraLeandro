package ar.or.centro08.curso.java.tpVehiculos.entities;

public class Radio {
    private String marca;
    private int potencia;

    public Radio(String marca, int potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }
    @Override
    public String toString() {
        return "radio {" + marca + "/" + potencia + "}";
    }
}
