package ar.or.centro08.curso.java.tpVehiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpVehiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
