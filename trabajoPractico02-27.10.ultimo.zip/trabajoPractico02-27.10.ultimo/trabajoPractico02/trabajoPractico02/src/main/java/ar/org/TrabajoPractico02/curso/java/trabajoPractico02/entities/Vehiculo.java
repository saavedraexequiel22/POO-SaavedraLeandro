package ar.org.TrabajoPractico02.curso.java.trabajoPractico02.entities;

public abstract class Vehiculo implements Comparable<Vehiculo> {// permite ordenar vehiculos por marca y
                                                                // moedelo.
    protected String marca;
    protected String modelo;
    protected double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public abstract String getDetalle();// permite que cada subclase implemente su propio detalle
                                        // especifico(polimporfismo).

    @Override
    public int compareTo(Vehiculo para) {
        String thisVehiculo = this.getMarca() + " ," + this.getModelo() + " ," + this.getPrecio();
        String paraVehiculo = para.getMarca() + " ," + para.getModelo() + " ," + para.getPrecio();
        return thisVehiculo.compareTo(paraVehiculo);
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // %s // Precio: $%,.2f",
                marca, modelo, getDetalle(), precio);
    }

}
