package ar.org.TrabajoPractico02.curso.java.trabajoPractico02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoPractico02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
