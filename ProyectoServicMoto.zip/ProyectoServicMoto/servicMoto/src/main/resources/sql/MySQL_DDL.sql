SELECT version();

drop DATABASE if EXISTS servicMoto;

CREATE DATABASE servicMoto;

use servicMoto;
-- tabla de clientes
CREATE Table Clientes(
    idCliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100)NOT NULL,
    telefono VARCHAR(20),
    email VARCHAR(100),
    direccion TEXT);

--tabla de moto 
CREATE TABLE Motos(
    id INT PRIMARY KEY AUTO_INCREMENT,
    idCliente INT,
    marca VARCHAR(50),
    modelo VARCHAR(50),
    año INT,
    patente VARCHAR(20) UNIQUE,
    FOREIGN KEY(idCliente) REFERENCES Clientes (idCliente));

--Tabla de empleados 
CREATE Table Empleados(
    idEmpleado INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) not NULL,
    apellido VARCHAR(100)not NULL,
    especialidad VARCHAR(100),
    telefono VARCHAR(20));

--tabla de servicios disponibles
CREATE Table Servicios(
    idServicio INT PRIMARY KEY AUTO_INCREMENT,
    nombreServicio VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2)NOT NULL);

--Tabla de ordenes de servicio
CREATE Table OrdenServicio(
    idOrden INT PRIMARY KEY AUTO_INCREMENT,
    idMoto INT,
    idEmpleado INT,
    fechaDeIngreso DATE,
    fechaDeEntrega DATE,
    estado VARCHAR(50),
    observaciones TEXT,
    FOREIGN key (idMoto) REFERENCES Motos(id),
    FOREIGN KEY (idEmpleado) REFERENCES Empleados(idEmpleado));

--Tabla de detalles de servicio realizados en cada orden
CREATE Table DetalleOrdenServicio(
    idDetalle INT PRIMARY KEY AUTO_INCREMENT,
    idOrden INT,
    idServicio INT,
    cantidad INT DEFAULT 1,
    subtotal DECIMAL(10,2),
    FOREIGN KEY(idOrden) REFERENCES OrdenServicio(idOrden),
    FOREIGN key (idServicio) REFERENCES Servicios(idServicio));

show tables;




