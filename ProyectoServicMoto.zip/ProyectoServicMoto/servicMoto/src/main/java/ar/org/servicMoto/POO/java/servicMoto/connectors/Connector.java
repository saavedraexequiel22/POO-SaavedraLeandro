package ar.org.servicMoto.POO.java.servicMoto.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {

    private static Connection conn = null;

    private static String url = "jdbc:mariadb://localhost:3306/servicMoto";
    private static String user = "root";
    private static String pass = "";

    private Connector() {
    }

    public static String getUrl() {
        return url;
    }

    public synchronized static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }

}
