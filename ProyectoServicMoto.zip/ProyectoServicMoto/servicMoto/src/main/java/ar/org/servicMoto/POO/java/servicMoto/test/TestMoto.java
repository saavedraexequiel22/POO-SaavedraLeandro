package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Moto;

public class TestMoto {
    public static void main(String[] args) {
        System.out.println("--moto01--");
        Moto moto01 = new Moto(2, 1, "zanella", "CR210", 2020, "ABC123");
        System.out.println(moto01);
    }

}
