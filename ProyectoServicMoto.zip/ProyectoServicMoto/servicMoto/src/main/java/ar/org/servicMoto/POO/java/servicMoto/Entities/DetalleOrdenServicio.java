package ar.org.servicMoto.POO.java.servicMoto.Entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor

public class DetalleOrdenServicio {
    private int idDetalle;
    private int idOrden;
    private int idServicio;
    private int cantidad;
    private double subTotal;
   
    
}
