package ar.org.servicMoto.POO.java.servicMoto.Entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Servicio {
    private int idServicio;
    private String nombreServicio;
    private String descripcion;
    private Double precio;
    
}
