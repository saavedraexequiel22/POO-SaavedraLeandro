package ar.org.servicMoto.POO.java.servicMoto.Entities;


import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class OrdenServicio {
    private int idOrden;
    private int idMoto;
    private int idEmpleado;
    private LocalDate fechaDeIngreso;
    private LocalDate fechaDeEntrega;
    private String estado;
    private String observaciones;
    






    
}
