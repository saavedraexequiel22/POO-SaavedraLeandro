package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Servicio;
import ar.org.servicMoto.POO.java.servicMoto.repositories.ServicioRepository;

@Controller

public class ServicioController {
    private ServicioRepository sr = new ServicioRepository();
    private String mensaje = "Ingrese un nuevo Servicio";

    @GetMapping("/servicio")
    public String getServicios(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        Servicio servicio = new Servicio();
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("ServicioForm", servicio);
        model.addAttribute("listaServicios", sr.getServicios(buscar));
        return "servicio";
    }

    @PostMapping("/servicio/guardar")
    public String guardarServicio(@ModelAttribute Servicio servicio) {
        sr.save(servicio);
        if (servicio.getIdServicio() > 0)
            mensaje = "Se guardo  el servicio " + servicio.getIdServicio();
        else
            mensaje = "no se guardo el servicio";
        return "redirect:/servicio";

    }

}
