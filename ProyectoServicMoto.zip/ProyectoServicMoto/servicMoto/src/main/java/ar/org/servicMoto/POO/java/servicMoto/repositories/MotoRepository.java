package ar.org.servicMoto.POO.java.servicMoto.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Moto;
import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;

public class MotoRepository {

    private Connection conn = Connector.getConnection();

    public void save(Moto moto) {
        if (moto == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into Motos(id,idCliente,marca,modelo,año,patente) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, moto.getId());
            ps.setInt(2, moto.getIdCliente());
            ps.setString(3, moto.getMarca());
            ps.setString(4, moto.getModelo());
            ps.setInt(5, moto.getAño());
            ps.setString(6, moto.getPatente());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                moto.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Moto moto) {
        if (moto == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from Motos where id=?")) {
            ps.setInt(1, moto.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Moto getById(int id) {
        return getAll()
                .stream()
                .filter(m -> m.getAño() == id)
                .findAny()
                .orElse(new Moto());

    }

    public List<Moto> getAll() {
        List<Moto> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from Motos")) {
            while (rs.next()) {
                list.add(
                        new Moto(
                                rs.getInt("id"),
                                rs.getInt("idCliente"),
                                rs.getString("marca"),
                                rs.getString("modelo"),
                                rs.getInt("año"),
                                rs.getString("patente")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Moto> getLikeMarca(String marca) {
        return getAll()
                .stream()
                .filter(a -> a.getMarca().toLowerCase().contains(marca.toLowerCase()))
                .toList();
    }
}
