package ar.org.servicMoto.POO.java.servicMoto.utils;

public class DataConfig {
     public static String getSO(){
        return  System.getProperty("os.name")+" "+
                System.getProperty("os.version")+" "+
                System.getProperty("os.arch");
    }

    public static String getJava(){
        return  System.getProperty("java.vm.version")+" "+
                System.getProperty("java.vm.name")+" "+
                System.getProperty("java.version.date");
                //+" "+
                //System.getProperty("java.vendor");
    }

    public static String getUserName(){
        return System.getProperty("user.name");
    }
    
}
