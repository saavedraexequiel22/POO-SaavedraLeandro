package ar.org.servicMoto.POO.java.servicMoto.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Servicio;
import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;

public class ServicioRepository {
    private Connection conn = Connector.getConnection();

    public void save(Servicio servicio) {
        if (servicio == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into Servicios (nombreServicio,descripcion,precio) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, servicio.getNombreServicio());
            ps.setString(2, servicio.getDescripcion());
            ps.setDouble(3, servicio.getPrecio());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                servicio.setIdServicio(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Servicio servicio) {
        if (servicio == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from Servicios where idServicio=?")) {
            ps.setInt(1, servicio.getIdServicio());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public Servicio getById(int id) {
        return getAll()
                .stream()
                .filter(a -> a.getIdServicio() == id)
                .findAny()
                .orElse(new Servicio());

    }

    public List<Servicio> getAll() {
        List<Servicio> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from Servicios")) {
            while (rs.next()) {
                list.add(
                        new Servicio(
                                rs.getInt("idServicio"),
                                rs.getString("nombreServicio"),
                                rs.getString("descripcion"),
                                rs.getDouble("precio")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Servicio> getServicios(String nombre_servicio) {
        return getAll()
                .stream()
                .filter(s -> s.getDescripcion().toLowerCase().contains(nombre_servicio.toLowerCase()))
                .toList();

    }
}
