package ar.org.servicMoto.POO.java.servicMoto.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.servicMoto.POO.java.servicMoto.Entities.DetalleOrdenServicio;
import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;

public class DetalleOrdenServicioRepository {
    private Connection conn = Connector.getConnection();

    public void save(DetalleOrdenServicio detalleOrdenServicio) {
        if (detalleOrdenServicio == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into DetalleOrdenServicio(idOrden,idServicio,cantidad,subtotal) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, detalleOrdenServicio.getIdOrden());
            ps.setInt(2, detalleOrdenServicio.getIdServicio());
            ps.setInt(3, detalleOrdenServicio.getCantidad());
            ps.setDouble(4, detalleOrdenServicio.getSubTotal());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                detalleOrdenServicio.setIdDetalle(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(DetalleOrdenServicio detalleOrdenServicio) {
        if (detalleOrdenServicio == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from DetalleOrdenServicio where idDetalle=?")) {
            ps.setInt(1, detalleOrdenServicio.getIdDetalle());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public DetalleOrdenServicio getById(int id) {
        return getAll()
                .stream()
                .filter(d -> d.getIdDetalle() == id)
                .findAny()
                .orElse(new DetalleOrdenServicio());
    }

    public List<DetalleOrdenServicio> getAll() {
        List<DetalleOrdenServicio> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from DetalleOrdenServicio")) {
            while (rs.next()) {
                list.add(
                        new DetalleOrdenServicio(
                                rs.getInt("idDetalle"),
                                rs.getInt("idOrden"),
                                rs.getInt("idServicio"),
                                rs.getInt("cantidad"),
                                rs.getDouble("subtotal")));

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}
