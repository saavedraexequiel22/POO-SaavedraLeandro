package ar.org.servicMoto.POO.java.servicMoto.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.servicMoto.POO.java.servicMoto.Entities.DetalleOrdenServicio;
import ar.org.servicMoto.POO.java.servicMoto.repositories.DetalleOrdenServicioRepository;

@Controller
public class DetalleOrdenServicioController {
    private DetalleOrdenServicioRepository dor = new DetalleOrdenServicioRepository();
    private String mensaje = "Ingrese un nuevo Detalle de Orden de Servicio";

    @GetMapping("/detalleOrdenServicio")
    public String getDetalles(Model model, @RequestParam(name = "orden", defaultValue = "") String orden) {
        DetalleOrdenServicio detalle = new DetalleOrdenServicio();
        model.addAttribute("DetalleForm", detalle);
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("ListaDetalles", dor.getAll());
        return "detalleOrdenServicio";
    }

    @PostMapping("/guardarDetalle")
    public String guardarDetalle(@ModelAttribute DetalleOrdenServicio detalle) {
        dor.save(detalle);
        if (detalle.getCantidad() > 0)
            mensaje = "Se guardo el detalle de la orden de servicio " + detalle.getIdDetalle();
        else
            mensaje = "No se guardo el detalle de la orden de servicio";
        return "redirect:/detalleOrdenServicio";
    }
}