package ar.org.servicMoto.POO.java.servicMoto.repositories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.servicMoto.POO.java.servicMoto.Entities.OrdenServicio;
import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;

public class OrdenServicioRepository {
     private Connection conn=Connector.getConnection();

    public void save(OrdenServicio ordenServicio){
        if(ordenServicio==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into OrdenesServicio (idMoto,idEmpleado,fechaDeIngreso,fechaDeEntrega,estado,observaciones) values (?,?,?,?,?,?)",
                    PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, ordenServicio.getIdMoto());
            ps.setInt(2, ordenServicio.getIdEmpleado());
            ps.setDate(3, Date.valueOf( ordenServicio.getFechaDeIngreso()));
            ps.setDate(4,Date.valueOf( ordenServicio.getFechaDeEntrega()));
            ps.setString(5, ordenServicio.getEstado());
            ps.setString(6, ordenServicio.getObservaciones());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) ordenServicio.setIdOrden(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(OrdenServicio ordenServicio){
        if(ordenServicio==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from OrdenesServicio where idOrden=?")){
            ps.setInt(1, ordenServicio.getIdOrden());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public OrdenServicio getById(int id){
        return getAll()
                        .stream()
                        .filter(o->o.getIdOrden()==id)
                        .findAny()
                        .orElse(new OrdenServicio());

    }

    public List<OrdenServicio> getAll(){
        List<OrdenServicio>list=new ArrayList<>();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from OrdenesServicio")){
            while(rs.next()){
                list.add(
                    new OrdenServicio(
                        rs.getInt("idOrden"),
                        rs.getInt("idMoto"),
                        rs.getInt("idEmpleado"),
                        rs.getDate("fechaDeIngreso").toLocalDate(),
                        rs.getDate("fechaDeEntrega").toLocalDate(),
                        rs.getString("estado"),
                        rs.getString("observaciones")
                    )
                );
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<OrdenServicio>getLikeEstado(String estado){
        return getAll()
                        .stream()
                        .filter(o->o.getEstado().toLowerCase().contains(estado.toLowerCase()))
                        .toList();
    }
    
}
