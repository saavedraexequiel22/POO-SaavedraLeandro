package ar.org.servicMoto.POO.java.servicMoto.controladores;

import ar.org.servicMoto.POO.java.servicMoto.utils.DataConfig;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.servicMoto.POO.java.servicMoto.connectors.Connector;

@Controller

public class ConfiguracionController {

    @GetMapping("configuracion")
    public String getConfiguracion(Model model) {
        model.addAttribute("so", DataConfig.getSO());
        model.addAttribute("java", DataConfig.getJava());
        model.addAttribute("username", DataConfig.getUserName());
        model.addAttribute("db", Connector.getUrl());
        return "configuracion";
    }
}
