package ar.org.servicMoto.POO.java.servicMoto.test;

import ar.org.servicMoto.POO.java.servicMoto.Entities.Empleado;
import ar.org.servicMoto.POO.java.servicMoto.repositories.EmpleadoRepository;

public class TestEmpleadoRepository {
    public static void main(String[] args) {
        EmpleadoRepository em = new EmpleadoRepository();

        Empleado empleado = new Empleado(0, "exe", "cardozo", "electricidad", "123455");
        em.save(empleado);
        System.out.println(empleado);

        em.remove(em.getById(11));
        System.out.println("--------------------");
        em.getAll().forEach(System.out::println);

        System.out.println("----------------------------");
        em.getLikeApellido("zo").forEach(System.out::println);

    }

}
